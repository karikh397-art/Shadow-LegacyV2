const canvas=document.getElementById('game'),ctx=canvas.getContext('2d');
const W=canvas.width,H=canvas.height;
const $=id=>document.getElementById(id);
const screens=['menu','character','chapters','shop','settings','cutscene','win','pause'];
let state={screen:'menu',char:'kael',chapter:0,coins:250,hp:100,bossHp:0,playing:false,paused:false,keys:{},attack:0,invuln:0,enemyX:960,heroX:240,vy:0,onGround:true,cut:0};
const chars={
 kael:{name:'KAEL',speed:5,jump:12,damage:16},
 nyx:{name:'NYX',speed:7,jump:13,damage:12},
 orion:{name:'ORION',speed:4,jump:11,damage:23}
};
const chapters=[
 {name:'La Forêt des Murmures',boss:'Le Gardien Sylvestre',hp:180,scene:[['KAEL','Le sceau est brisé… quelque chose nous attend dans cette forêt.'],['NYX','Alors avançons. Notre héritage commence ici.']]},
 {name:'La Cité Brisée',boss:'Le Seigneur d’Acier',hp:260,scene:[['ORION','La cité a été abandonnée, mais ses machines sont toujours actives.'],['KAEL','Le prochain fragment se trouve au cœur des ruines.']]},
 {name:'Le Temple du Néant',boss:'L’Archonte du Néant',hp:360,scene:[['NYX','Plus nous approchons, plus l’ombre devient forte.'],['ORION','Nous terminerons ce que nos ancêtres ont commencé.']]},
 {name:'Le Trône des Ombres',boss:'Le Roi Sans Nom',hp:500,scene:[['KAEL','Voici la source de tout ce chaos.'],['ROISANSNOM','Vous êtes venus jusqu’ici… alors montrez-moi votre héritage.']]}
];
const shop=[
 ['Lame renforcée','+5 dégâts',120,'damage'],
 ['Cœur d’ombre','+20 PV',100,'hp'],
 ['Bottes du vent','+1 vitesse',150,'speed'],
 ['Armure astrale','+30 PV',180,'hp2'],
 ['Lame solaire','+12 dégâts',250,'damage2'],
 ['Cape spectrale','Esquive améliorée',220,'dodge'],
 ['Skin : Néon','Tenue lumineuse',180,'skinNeon'],
 ['Skin : Ombre','Tenue furtive',180,'skinShadow'],
 ['Skin : Flamme','Tenue ardente',220,'skinFire']
];
let upgrades={damage:0,hp:0,speed:0,skinNeon:0,skinShadow:0,skinFire:0};

function show(id){screens.forEach(s=>$(s).classList.toggle('hidden',s!==id)); if(id==='menu') draw();}
function refreshCoins(){ $('coins').textContent=state.coins; $('hudCoins').textContent=state.coins; }
function buildChapters(){ $('chapterList').innerHTML=chapters.map((c,i)=>`<button ${i>state.chapter?'disabled':''} data-ch="${i}">CHAPITRE ${i+1}<br>${c.name}<br><small>Boss : ${c.boss}</small></button>`).join(''); document.querySelectorAll('[data-ch]').forEach(b=>b.onclick=()=>startChapter(+b.dataset.ch));}
function buildShop(){ $('shopList').innerHTML=shop.map((x,i)=>`<div class="shop-item"><b>${x[0]}</b><span>${x[1]}</span><button data-buy="${i}">${x[2]} Éclats</button></div>`).join(''); document.querySelectorAll('[data-buy]').forEach(b=>b.onclick=()=>buy(+b.dataset.buy)); refreshCoins();}
function buy(i){let x=shop[i];if(state.coins<x[2])return alert('Pas assez d’éclats !');state.coins-=x[2];upgrades[x[3]]=(upgrades[x[3]]||0)+1;refreshCoins();}
function selectedChar(){return chars[state.char]}
function startChapter(i){state.chapter=i;state.hp=100+upgrades.hp*20+upgrades.hp2*30;state.bossHp=chapters[i].hp;state.heroX=220;state.enemyX=980;state.vy=0;state.onGround=true;state.playing=false;state.cut=0;show('cutscene');nextLine();}
function nextLine(){let lines=chapters[state.chapter].scene;if(state.cut<lines.length){$('speaker').textContent=lines[state.cut][0];$('line').textContent=lines[state.cut][1];state.cut++;}else startGame();}
function startGame(){state.playing=true;state.paused=false;show('hud');requestAnimationFrame(loop);}
function endChapter(){state.playing=false;state.coins+=100+state.chapter*50;if(state.chapter<chapters.length-1)state.chapter++;refreshCoins();$('winTitle').textContent='BOSS VAINCU';$('winText').textContent=`Tu as terminé ${chapters[state.chapter?state.chapter-1:0].name}. Récompense : éclats bonus.`;show('win');}
function attack(){if(!state.playing||state.paused)return;state.attack=12;let c=selectedChar(),range=105; if(Math.abs(state.enemyX-state.heroX)<range){state.bossHp-=c.damage+upgrades.damage*5+upgrades.damage2*12;if(state.bossHp<=0)endChapter();}}
function update(){if(!state.playing||state.paused)return;let c=selectedChar(),k=state.keys;
 if(k.ArrowLeft||k.a)state.heroX-=c.speed+upgrades.speed; if(k.ArrowRight||k.d)state.heroX+=c.speed+upgrades.speed;
 state.heroX=Math.max(80,Math.min(W-250,state.heroX)); if((k[' ']||k.Space)&&state.onGround){state.vy=-c.jump;state.onGround=false;k[' ']=false;k.Space=false}
 state.vy+=.55;let gy=590;if(state.heroY===undefined)state.heroY=gy;state.heroY+=state.vy;if(state.heroY>=gy){state.heroY=gy;state.vy=0;state.onGround=true}
 if(state.invuln>0)state.invuln--;if(state.attack>0)state.attack--;
 // Boss follows at a distance and occasionally attacks.
 let dx=state.heroX-state.enemyX;if(Math.abs(dx)>150)state.enemyX+=Math.sign(dx)*1.1;
 if(Math.abs(dx)<125 && Math.random()<0.025 && state.invuln===0){state.hp-=10;state.invuln=45;if(state.hp<=0){state.hp=100;state.heroX=220;}}
 $('hp').textContent=Math.max(0,state.hp);$('bossHp').textContent=Math.max(0,state.bossHp);$('hpBar').style.width=Math.max(0,state.hp)+'%';
}
function draw(){ctx.clearRect(0,0,W,H);let t=Date.now()/1000;
 let g=ctx.createLinearGradient(0,0,0,H);g.addColorStop(0,'#080b1c');g.addColorStop(1,'#171022');ctx.fillStyle=g;ctx.fillRect(0,0,W,H);
 // moon and background
 ctx.fillStyle='#cfc8ff';ctx.beginPath();ctx.arc(1030,120,55,0,Math.PI*2);ctx.fill();
 for(let i=0;i<12;i++){let x=(i*123)%W;let h=120+(i%4)*35;ctx.fillStyle='#0b1020';ctx.fillRect(x,590-h,80,h);}
 ctx.fillStyle='#24203b';ctx.fillRect(0,590,W,130);
 if(state.playing){drawFighter(state.heroX,state.heroY||590,state.char,true);drawBoss(state.enemyX,590,chapters[state.chapter].boss);}
}
function drawFighter(x,y,type,hero){ctx.save();let c=chars[type];if(hero&&state.invuln%2===1)ctx.globalAlpha=.45;
 let body=type==='kael'?'#8f6cff':type==='nyx'?'#56d9ff':'#ffb84d';
 if(upgrades.skinNeon) body='#53f3ff';
 if(upgrades.skinShadow) body='#5b5b6e';
 if(upgrades.skinFire) body='#ff694f';
 ctx.fillStyle=body;ctx.fillRect(x,y-80,44,80);ctx.fillStyle='#f0d2bd';ctx.beginPath();ctx.arc(x+22,y-98,18,0,Math.PI*2);ctx.fill();
 ctx.fillStyle='#171322';ctx.fillRect(x+5,y-115,34,12);ctx.fillStyle='#ddd';ctx.fillRect(x+12,y-75,8,40);ctx.restore();
 if(hero&&state.attack>0){ctx.strokeStyle='#f6e27a';ctx.lineWidth=10;ctx.beginPath();ctx.arc(x+25,y-50,60,-.9,.9);ctx.stroke();}
}
function drawBoss(x,y,name){ctx.fillStyle='#b84b6f';ctx.fillRect(x,y-120,70,120);ctx.fillStyle='#2c1024';ctx.beginPath();ctx.arc(x+35,y-145,28,0,Math.PI*2);ctx.fill();ctx.fillStyle='#fff';ctx.font='18px system-ui';ctx.fillText(name,x-35,y-175);}
function loop(){update();draw();if(state.playing&&!state.paused)requestAnimationFrame(loop);}

document.querySelectorAll('[data-action]').forEach(b=>b.onclick=()=>{
 let a=b.dataset.action;
 if(a==='play')show('character');
 if(a==='shop'){buildShop();show('shop')}
 if(a==='settings')show('settings');
 if(a==='chapters'){buildChapters();show('chapters')}
 if(a==='character')show('character');
 if(a==='menu'){state.playing=false;show('menu')}
 if(a==='nextLine')nextLine();
 if(a==='resume'){state.paused=false;show('hud');requestAnimationFrame(loop)}
});
document.querySelectorAll('.char-card').forEach(b=>b.onclick=()=>{state.char=b.dataset.char;document.querySelectorAll('.char-card').forEach(x=>x.classList.remove('selected'));b.classList.add('selected')});
addEventListener('keydown',e=>{state.keys[e.key]=true;if(e.key==='j'||e.key==='J')attack();if(e.key==='Escape'&&state.playing){state.paused=true;show('pause')}});
addEventListener('keyup',e=>state.keys[e.key]=false);
refreshCoins();draw();
