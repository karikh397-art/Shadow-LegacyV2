# Shadow Legacy — V1

Prototype de jeu d'action/aventure jouable dans un navigateur et préparé pour être empaqueté en application PC via Electron.

## Contenu
- Écran d'accueil : Jouer / Boutique / Paramètres
- 3 personnages sélectionnables
- 4 chapitres dans l'ordre
- 4 boss
- Cinématiques/dialogues avant chaque chapitre
- Déplacement, saut, attaque, esquive visuelle
- Boutique avec améliorations de dégâts, PV, vitesse et équipement
- Sauvegarde de progression prévue pour les prochaines versions
- Version Electron pour créer un exécutable PC

## Jouer tout de suite
Ouvre `index.html` dans un navigateur.

## Préparer la version Steam/PC
1. Installe Node.js.
2. Dans ce dossier, lance `npm install`.
3. Lance `npm start` pour tester la version Electron.
4. Lance `npm run dist` pour produire un build PC.

Pour publier réellement sur Steam, il faut ensuite créer un compte Steamworks, préparer les informations de l'application, le build et les dépôts SteamPipe, puis respecter les exigences de Steamworks. Ce dossier est un prototype technique, pas encore une version commerciale finale.
